﻿using MauiBookAppForProduction;
using MauiBookAppForProduction.Model;
using Microsoft.Maui.Controls;

namespace MauiBookAppForProduction
{
    public partial class MainPage : ContentPage
    {

        private List<SampleData>? obj_mainContent;
        public MainPage()
        {
            InitializeComponent();
            searchBar.Text = "عٰلَمِ";
            GetSearchData(searchBar);
        }

        private void SearchBar_SearchButtonPressed(object sender, EventArgs e)
        {
            GetSearchData(sender);
        }

        private async void GetSearchData(object sender)
        {
            try
            {
                SearchBar searchBar = (SearchBar)sender;
                if (searchBar is not null)
                {
                    if (string.IsNullOrEmpty(searchBar.Text.Trim()))
                    {
                        ListOfContents.ItemsSource = null;
                        searchBar.Unfocus();

                    }
                    else
                    {
                        obj_mainContent?.Clear();
                        string SearchText = searchBar.Text.Trim();
                        if (SearchText.Length > 1)
                        {
                            SampleDataRepository objSampleDataRepository = new SampleDataRepository();
                            obj_mainContent = objSampleDataRepository.GetExistingCollectionData().Where(x => x.Ayat_ArabicText is not null && x.Ayat_ArabicText.Contains(SearchText)).ToList();
                            await Task.Delay(5);
                            foreach (SampleData item in obj_mainContent)
                            {
                                if (!string.IsNullOrEmpty(SearchText) && item.Ayat_ArabicText.Contains(SearchText, StringComparison.OrdinalIgnoreCase))
                                {
                                    var startIndex = item.Ayat_ArabicText.IndexOf(SearchText, StringComparison.OrdinalIgnoreCase);
                                    var beforeMatch = item.Ayat_ArabicText.Substring(0, startIndex);
                                    var match = item.Ayat_ArabicText.Substring(startIndex, SearchText.Length);
                                    var afterMatch = item.Ayat_ArabicText.Substring(startIndex + SearchText.Length);

                                    item.TextBeforeMatch = beforeMatch;
                                    item.MatchedText = match;
                                    item.TextAfterMatch = afterMatch;
                                }
                            }
                            ListOfContents.ItemsSource = obj_mainContent;

                        }
                        else
                        {
                            ListOfContents.ItemsSource = null;

                        }
                    }
                }
            }
            catch { }
        }

    }

}
