﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiBookAppForProduction.Model
{
    public class SampleData
    {
        public int Sura_Number { get; set; }
        public int Ayat_Number { get; set; }
        public string? Ayat_ArabicText { get; set; }
        public string? Ayat_ByLanguage { get; set; }
        public string? Sura_NameWithNumber_ByLanguage { get; set; }
        public string? Font_ByLanguage { get; set; } = "AlQalamnew";
        public string? FontSize_byLanguage { get; set; }
        public string? Sura_Name_inArabic { get; set; }
        public int? LanguageID { get; set; }
        public string? Append_Bismillah_Text { get; set; }
        public string? Ayat_English { get; set; }
        public string? Ayat_Marathi { get; set; }
        public string? Ayat_Urdu { get; set; }
        public bool ShowNextButton { get; set; } = true;
        public bool ShowPrevioustButton { get; set; } = true;
        public string? PreviousButtonText { get; set; }
        public string? NextButtonText { get; set; }
        public string? ContentForWebView { get; set; }
        public bool ShowWebView { get; set; } = false;
        public bool ShowContentView { get; set; } = true;
        public string? TextDirection { get; set; } = "LeftToRight";
        public string? TextBeforeMatch { get; set; }
        public string? MatchedText { get; set; }
        public string? TextAfterMatch { get; set; }
        public string? AyatWithNoDiacritics { get; set; }
        public string? WebViewHeight { get; set; } = "45";

    }
}
